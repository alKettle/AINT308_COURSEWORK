//James Rogers Jan 2022 (c) Plymouth University
#include <iostream>

#include<opencv2/opencv.hpp>
#include<opencv2/opencv_modules.hpp>

using namespace std;
using namespace cv;

int main(){

    //Path of image folder
    string PathToFolder = "../Task1/Car Images/";

    //Loop through the 30 car images
    for(int n=0; n<47; ++n){

        //Each image is named 0.png, 1.png, 2.png, etc. So generate the image file path based on n and the folder path
        string PathToImage = PathToFolder+to_string(n)+".png";

        cout<<PathToImage<<endl;

        //Load car image at the file paths location
        Mat Car=imread(PathToImage);

        //Your code goes here. The example code below shows you how to read the red, green, and blue colour values of the
        //pixel at position (0,0). Modify this section to check not just one pixel, but all of them in the 640x480 image
        //(using for-loops), and using the RGB values classifiy if a given pixel looks red, green, blue, or other.


        //initiate colour variables to 0
        int RED = 0;
        int BLUE = 0;
        int GREEN = 0;


        for(int x=160; x<480; x++){ //for loop for the x axis pixels going from 160 to 480

            for(int y=120; y<360; y++){ //for loop for the y axis pixels from 120 to 360

                Vec3b PixelValue = Car.at<Vec3b>(y,x); //sets the variable PixelValue to be the values of y and x

                //Calculations for each of the colours
                BLUE = PixelValue[0] + BLUE;
                GREEN = PixelValue[1] + GREEN;
                RED = PixelValue[2] + RED;

            }
        }



        if (BLUE > RED && BLUE > GREEN){ //if theres more blue then print
            cout <<"The car is Blue"<<endl;
        }
        else if (GREEN > BLUE && GREEN > RED){ //if theres more green then print
            cout <<"The car is Green"<<endl;
        }
        else if (RED > GREEN && RED > BLUE){ //if theres more red then print
            cout <<"The car is Red"<<endl;
        }

        rectangle(Car, Rect(160,120, 320,240), Scalar(179,25,255), 4); //Prints a pink rectangle on the area where the pixels are being read.


        //display the car image untill x is pressed
        while(waitKey(10)!='x'){
            imshow("Car", Car);
        }


    }

}




















