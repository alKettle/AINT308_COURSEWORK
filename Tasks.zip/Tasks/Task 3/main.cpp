//James Rogers Jan 2021 (c) Plymouth University
#include<iostream>
#include<opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main()
{

    //Path to image file
    string Path = "../Task3/PCB Images/";

    //loop through component images
    for(int n=0; n<20; ++n){

        //read PCB and component images
        Mat PCB = imread(Path+"PCB.png");
        Mat Component = imread(Path+"Component"+to_string(n)+".png");

        //================Your code goes here=====================

        Mat Output_Image; //Creates variable

        matchTemplate( PCB, Component, Output_Image, TM_SQDIFF_NORMED); //Uses the matchTemplate function to find the error of the component across the PCB

        double Min_Val, Max_Val; //Min/Max value variables
        Point Min_Loc, Max_Loc; //Min/Max location variables
        minMaxLoc( Output_Image, &Min_Val, &Max_Val, &Min_Loc, &Max_Loc); //Will find the min/max points on the image

        cout <<"Minimum Error Value: " << Min_Val << endl; //prints the error value
        Point Component_Size (Component.size().width, Component.size().height); //Used for drawing a rectangle round the component

        if (Min_Val > 0.04){ //is error value is more than 0.04
            cout << "ERROR: COMPONENT NOT FOUND!!" << endl; //print an error message
        }
        else if (Min_Val < 0.04){ //if less than 0.04
            rectangle(PCB, Min_Loc, Min_Loc+Component_Size, Scalar(179,25,255), 4); //then print rectangle on image locating the component
        }




        //display the results untill x is pressed
        while(waitKey(10)!='x'){
            imshow("Target", Component);
            imshow("PCB", PCB);
            imshow("Output_Image", Output_Image);
        }

    }

}
