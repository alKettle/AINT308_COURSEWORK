//James Rogers Mar 2022 (c) Plymouth University
#include<iostream>
#include<fstream>
#include<opencv2/opencv.hpp>

using namespace std;
using namespace cv;

//a drawing function that can draw a line based on rho and theta values.
//useful for drawing lines from the hough line detector.
void lineRT(Mat &Src, Vec2f L, Scalar color, int thickness){
    Point pt1, pt2;
    double a = cos(static_cast<double>(L[1]));
    double b = sin(static_cast<double>(L[1]));
    double x0 = a*static_cast<double>(L[0]);
    double y0 = b*static_cast<double>(L[0]);
    pt1.x = cvRound(x0 + 10000*(-b));
    pt1.y = cvRound(y0 + 10000*(a));
    pt2.x = cvRound(x0 - 10000*(-b));
    pt2.y = cvRound(y0 - 10000*(a));
    line(Src, pt1, pt2, color, thickness, LINE_AA);
}

int main()
{

    //Open video file
    VideoCapture CarVideo("../Task5/DashCam.mp4");
    if(!CarVideo.isOpened()){
        cout<<"Error opening video"<<endl;
        return -1;
    }

    //main program loop
    while(true){

        //open the next frame from the video file, or exit the loop if its the end
        Mat Frame;
        CarVideo.read(Frame);
        if(Frame.empty()){
            break;
        }

        //==========================Your code goes here==========================

        Mat EdgeMap; //Stores the images for the edge map
        Mat ColourMask; //Stores the images for the colour mask

        vector<Vec2f> lines; //Lines are stored on Vec2f data type, which stores two floating point values

        inRange(Frame, Vec3b(52,0,0), Vec3b(90,255,255), ColourMask); //Thresholds the Frame image against the ranges and outputs the ColourMask

        dilate(ColourMask, ColourMask, getStructuringElement(MORPH_ELLIPSE, Size(15,15)));//Increases the size of the white

        bitwise_not(ColourMask, ColourMask);// Invert the ColourMask

        //canny(inputMat, outputMat, lowerThreshold, upperThreshold)
        Canny(Frame, EdgeMap, 150, 160); //Creates clean single pixel edges for the input Frame and outputs the EdgeMap

        bitwise_and(ColourMask,EdgeMap, EdgeMap); //Logically ands the images together

        //HoughLines (edgeMap, lines, rhoRes, thetaRes, Threshold, 0, 0);
        HoughLines(EdgeMap, lines, 1, 0.01, 260, 0, 0);                     //Line detection algorithm on EdgeMaps



        double Y1 = 360;//sets variable to have a vlaue of 360
        double Y2 = 720;//sets variable to have a value of 720

        //Stores a point with x and y coordinates for the top/bottom left and top/bottom right of the lines
        Point SumLeft1(0,0);
        Point SumLeft2(0,0);
        Point SumRight1(0,0);
        Point SumRight2(0,0);

        int LLinesTotal = 0; //Initiates the variable to 0
        int RLinesTotal = 0; //Initiates the variable to 0


        for(int n = 0; n < lines.size(); ++n){ //for-loop
            Vec2f L = lines[n]; //Stores the lines value
            float Theta = L[1]*180/M_PI;//Sets value of theta


            if (Theta > 30 && Theta < 60){ //if theta is more than 30 and less than 60 then...
                lineRT(Frame, lines[n], Scalar(255, 0, 0), 1); //Draws the detected lines
                double X1 = ((L[0]/sin(L[1])) - (double)Y1) * (tan(L[1])); //Calculates position of X1
                double X2 = ((L[0]/sin(L[1])) - (double)Y2) * (tan(L[1])); //Calculates postion of X2
                Point InterSect1(X1,Y1); //Stores postion of the top points
                Point InterSect2(X2,Y2); //Stores position of the bottom points
                circle(Frame, InterSect1, 1, Scalar(179, 25, 255), 6); //Print a circle of the stored top points
                circle(Frame, InterSect2, 1, Scalar(000, 255, 000), 6); //Print a circle of the stored bottom points
                LLinesTotal++; //Increment variable

                SumLeft1 = SumLeft1 + InterSect1; //Total sum of top left is calculated
                SumLeft2 = SumLeft2 + InterSect2; //Total sum of bottom left is calculated

            }
            else if (Theta > 90 && Theta < 180){ //if theta is more than 90 and less than 180
                lineRT(Frame, lines[n], Scalar(255, 0, 0), 1);//Draws the detected lines
                double X1 = ((L[0]/sin(L[1])) - (double)Y1) * (tan(L[1])); //Calculates position of X1
                double X2 = ((L[0]/sin(L[1])) - (double)Y2) * (tan(L[1])); //Calculates postion of X2
                Point InterSect1(X1,Y1); //Stores postion of the top points
                Point InterSect2(X2,Y2); //Stores position of the bottom points
                circle(Frame, InterSect1, 1, Scalar(179, 25, 255), 6); //Print a circle of the stored top points
                circle(Frame, InterSect2, 1, Scalar(000, 255, 000), 6);  //Print a circle of the stored bottom points
                RLinesTotal++; //Increment variable

                SumRight1 = SumRight1 + InterSect1; //Total sum of top right is calculated
                SumRight2 = SumRight2 + InterSect2; //Total sum of bottom right is calculated

            }
        }

        double LinesTotal = lines.size();           //Sets the variable to be size of lines

        cout<<LLinesTotal<<" "<<RLinesTotal<<endl;  //Prints the left and right lines totals to the terminal

        if (LLinesTotal > 0 && RLinesTotal > 0){ //if the total values are more than 0 then...

        //Calculates the average of top & bottom left point
        Point AvrgLeft1 = SumLeft1 / LLinesTotal;
        Point AvrgLeft2 = SumLeft2 / LLinesTotal;

        //Calculates the average of top & bottom right point
        Point AvrgRight1 = SumRight1 / RLinesTotal;
        Point AvrgRight2 = SumRight2 / RLinesTotal;

        Point AvrgTop = (AvrgLeft1 + AvrgRight1) / 2; //Calculates the average of the top points
        Point AvrgBottom = (AvrgLeft2 + AvrgRight2) / 2; //Calculates the average of the bottom points

        //Draws lines from the top average points to the bottom average points
        line (Frame, AvrgLeft1, AvrgLeft2, Scalar(179,25,255), 2);
        line (Frame, AvrgRight1, AvrgRight2, Scalar(179,25,255), 2);

        vector <Point> PointMarks = {AvrgRight2, AvrgRight1, AvrgLeft1, AvrgLeft2};             //Sets the vpoint marks to be the points of all the different averages
        vector<vector<Point>>ContPoints = {PointMarks};                                     //Sets the cont points to be the points stored in PointMarks
        drawContours(Frame, ContPoints, 0, Scalar(0,255,0), -1);                            //Will draw a rectangle on the lane using the average points stored in ContPoints

        line (Frame, AvrgTop, AvrgBottom, Scalar(179,25,255), 3);                        //Draws a line from the top average point to the bottom average point
        }


        //display frame
        imshow("Video", Frame);
        imshow("edgeMap", EdgeMap);
        imshow("ColourMask", ColourMask);
        waitKey(10);
    }
}



