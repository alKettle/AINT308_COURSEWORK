//James Rogers Nov 2020 (c) Plymouth University
#include <iostream>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <stdio.h>

using namespace cv;
using namespace std;

int main(int argc, char** argv)
{
    //Calibration file paths (you need to make these)
    string intrinsic_filename = "C:/AINT308Part2/Task4/intrinsics.xml";
    string extrinsic_filename = "C:/AINT308Part2/Task4/extrinsics.xml";

    //================================================Load Calibration Files===============================================
    //This code loads in the intrinsics.xml and extrinsics.xml calibration files, and creates: map11, map12, map21, map22.
    //These four matrices are used to distort the camera images to apply the lense correction.
    Rect roi1, roi2;
    Mat Q;
    Size img_size = {640,480};

    FileStorage fs(intrinsic_filename, FileStorage::READ);
    if(!fs.isOpened()){
        printf("Failed to open file %s\n", intrinsic_filename.c_str());
        return -1;
    }

    Mat M1, D1, M2, D2;
    fs["M1"] >> M1;
    fs["D1"] >> D1;
    fs["M2"] >> M2;
    fs["D2"] >> D2;

    fs.open(extrinsic_filename, FileStorage::READ);
    if(!fs.isOpened())
    {
        printf("Failed to open file %s\n", extrinsic_filename.c_str());
        return -1;
    }
    Mat R, T, R1, P1, R2, P2;
    fs["R"] >> R;
    fs["T"] >> T;

    stereoRectify( M1, D1, M2, D2, img_size, R, T, R1, R2, P1, P2, Q, CALIB_ZERO_DISPARITY, -1, img_size, &roi1, &roi2 );

    Mat map11, map12, map21, map22;
    initUndistortRectifyMap(M1, D1, R1, P1, img_size, CV_16SC2, map11, map12);
    initUndistortRectifyMap(M2, D2, R2, P2, img_size, CV_16SC2, map21, map22);

    //===============================================Stereo SGBM Settings==================================================
    //This sets up the block matcher, which is used to create the disparity map. The various settings can be changed to
    //obtain different results. Note that some settings will crash the program.

    int SADWindowSize=5;            //must be an odd number >=3
    int numberOfDisparities=256;    //must be divisable by 16

    Ptr<StereoSGBM> sgbm = StereoSGBM::create(0,16,3);
    sgbm->setBlockSize(SADWindowSize);
    sgbm->setPreFilterCap(63);
    sgbm->setP1(8*3*SADWindowSize*SADWindowSize);
    sgbm->setP2(32*3*SADWindowSize*SADWindowSize);
    sgbm->setMinDisparity(0);
    sgbm->setNumDisparities(numberOfDisparities);
    sgbm->setUniquenessRatio(10);
    sgbm->setSpeckleWindowSize(100);
    sgbm->setSpeckleRange(32);
    sgbm->setDisp12MaxDiff(1);
    sgbm->setMode(StereoSGBM::MODE_SGBM);

    //==================================================Main Program Loop================================================
    int ImageNum=0; //current image index
    int cm = 30;

    while (1){
        //Load images from file (needs changing for known distance targets)
        Mat Left =imread("../Task4/Unknown Targets/left" +to_string(ImageNum)+".jpg");
        Mat Right=imread("../Task4/Unknown Targets/right"+to_string(ImageNum)+".jpg");


        //Mat Left =imread("../Task4/Distance Targets/left" +to_string(cm)+"cm.jpg");
        //Mat Right=imread("../Task4/Distance Targets/right"+to_string(cm)+"cm.jpg");
        cout<<"Loaded image: "<<ImageNum<<endl;

        //Distort image to correct for lens/positional distortion
        remap(Left, Left, map11, map12, INTER_LINEAR);
        remap(Right, Right, map21, map22, INTER_LINEAR);

        //Match left and right images to create disparity image
        Mat disp16bit, disp8bit;
        sgbm->compute(Left, Right, disp16bit);                               //compute 16-bit greyscalse image with the stereo block matcher
        disp16bit.convertTo(disp8bit, CV_8U, 255/(numberOfDisparities*16.)); //Convert disparity map to an 8-bit greyscale image so it can be displayed (Only for imshow, do not use for disparity calculations)

        //==================================Your code goes here===============================

        int Grey = 0;//create variable for colour and initialise it to 0
        int AVR; //Initiate average variable
        int NumberOfPixels = 0; //create and initiate variable for the number of pixels to 0
        int Disparity = 0; //create disparity variable and set to 0
        int Distance = 0; //create distance variable and set tp 0
        Mat distanceMap; //Stores images for the distance map


        for(int x = 370; x < 380; x++ ){ //for-loop that will go from x-axis position 370 to x-axis position 380


            for(int y = 220; y < 230; y++ ){ //for-loop that will go from y-axis position 220 to y-axis position 230

                ushort Pixel_Value = disp16bit.at<ushort>(y,x); //sets the PixelValue to be the values of x and y. Using ushort because of 16-bit grey pixel and gives more detailed colour data

                Grey = Pixel_Value + Grey; //Calculates the number of grey pixels

                NumberOfPixels++;//adds to the number of pixels variable


            }
        }

        cout << "Total Pixel Value: " << Grey << endl; //Prints the total pixel grey value to the terminal
        rectangle(disp8bit, Rect(370,220, 10,10), Scalar(255,255,255), 2); //Draws a rectangle around the area where the pixels are being read

        AVR = Grey/NumberOfPixels; //Calculates the average
        cout << "Disparity: " << AVR << endl; //Prints the average value to the terminal

        Disparity = AVR;                           //Sets the value of disparity to be the value of the average
        Distance = 62283.07692 / Disparity;        //Calculates the distance by dividing the total average (calculated in Excel) by the disparity
        cout << "Distance: " << Distance << endl;  //Prints the calculated distance to the terminal





        //display images untill x is pressed
        int key=0;
        while(waitKey(10)!='x')
        {
            imshow("left", Left);
            imshow("right", Right);
            imshow("disparity", disp8bit);
        }

        //move to next image
        ImageNum++;
        cm+=10;
        if(ImageNum>12)
        {
            ImageNum=0;
            cm = 30;
        }
    }

    return 0;
}





